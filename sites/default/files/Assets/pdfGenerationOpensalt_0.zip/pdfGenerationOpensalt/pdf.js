var pdfData={
		"CFDocument": {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
			"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
			"lastChangeDateTime": "2018-02-26T18:14:55+00:00",
			"CFPackageURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFPackages\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"licenseURI": {
				"title": "Attribution 4.0 International",
				"identifier": "7eb5e85a-6fef-59f4-a5f2-6665ab9681db",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFLicenses\/7eb5e85a-6fef-59f4-a5f2-6665ab9681db"
			},
			"creator": "Brandon",
			"publisher": "ACT Inc",
			"title": "Demo Framework",
			"version": "1.0",
			"description": "This framework will be a test case",
			"language": "en",
			"adoptionStatus": "Draft",
			"statusStartDate": "2013-02-01",
			"notes": "note field in cf doc"
		},
		"CFItems": [{
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
			"identifier": "a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
			"lastChangeDateTime": "2018-02-08T23:09:13+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"fullStatement": "My _current_ children are in an alphabetical list: \r\na. Madelyn\r\nb. Jocelyn\r\n\r\nA numbered list:\r\n1. Madelyn\r\n2. Jocelyn\r\n\r\nAnd a bulleted list\r\n* Madelyn\r\n* Jocelyn",
			"statusStartDate": "2013-02-01"
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/b5a3a0ae-05e5-11e8-a812-537ba182d282",
			"identifier": "b5a3a0ae-05e5-11e8-a812-537ba182d282",
			"lastChangeDateTime": "2018-01-30T17:49:29+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"fullStatement": "> My second child's name is Jocelyn.\r\n\r\n**Bold** \r\n*Italic*\r\n# Heading\r\n* List\r\n\r\n* List\r\n1. Numbered List\r\n\r\n-----",
			"statusStartDate": "2013-02-01"
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/e4c97cae-209e-11e8-b90c-b5e39335077d",
			"identifier": "e4c97cae-209e-11e8-b90c-b5e39335077d",
			"lastChangeDateTime": "2018-03-05T17:59:15+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"CFItemType": "Career Pathway",
			"CFItemTypeURI": {
				"title": "Career Pathway",
				"identifier": "39ff729e-6b84-11e7-a04e-32dbd3c9a467",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItemTypes\/39ff729e-6b84-11e7-a04e-32dbd3c9a467"
			},
			"conceptKeywords": ["research", "teaching"],
			"educationLevel": ["PR", "TK"],
			"humanCodingScheme": "H.A.Framework.A.B.1",
			"fullStatement": "My wife is an 8th grade math teacher in a downtown Tucson, Arizona charter school, located in the basement of our city\u2019s historic YMCA. Her primary job is introducing 13-year-olds to solving linear equations and applying quadratic functions (and I dare readers here to take on such a project on a daily basis!). \r\n\r\nShe doesn\u2019t need any research-based evidence to know that her job is made considerably easier\u2014and her students learn more effectively and efficiently\u2014when her students are supporting each other during classroom activities, when they are staying calm and not getting angry or upset, when they set goals and don\u2019t give up, and when they make good choices about handling the difficult decisions that come your way when you are 13 in the year 2018. \r\n\r\nShe and her colleagues discuss and reflect upon this part of their work every single day\u2014but they hardly ever use formal or technical terms for what they are describing as their hopes for student behaviors, and they don\u2019t really give much attention to what researcher might determine is the \u201cright\u201d way to organize or label these behaviors. They use commonplace descriptors: kind and helpful; calm and cool; and persistent and organized.",
			"abbreviatedStatement": "Need Research? Ask ACT!",
			"notes": "School systems\u2014at whatever level, be it global, national, state, district, school, or classroom\u2014ought to be clear with themselves and their community about their commitments to student learning, especially in the social and emotional areas, so clarifying and communicating widely their particular common terminology is very valuable. (I discuss this in step 2 of my recent ACT e-book, Eight Steps to Strengthening SEL in Your School or District). \r\n\r\nAfter much research and consideration, ACT has chosen a framework known as the Big Five Factors (BFF) for Social and Emotional Learning (SEL) assessments, and the ACT\u00ae Holistic Framework\u2122. The Big Five Factors, identified after many years of research and analysis, are these: Conscientiousness, Agreeableness, Emotional Stability, Openness, and Extraversion. \r\n\r\nFor our SEL assessment, ACT Tessera\u2122, we\u2019ve re-named the Big Five Factors with labels more widely used by educators, parents and policymakers.",
			"language": "en",
			"statusStartDate": "2013-02-01"
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/987d0bd2-05e5-11e8-8801-5b23b21d3bc3",
			"identifier": "987d0bd2-05e5-11e8-8801-5b23b21d3bc3",
			"lastChangeDateTime": "2018-03-05T17:59:15+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"CFItemType": "Content Standard",
			"CFItemTypeURI": {
				"title": "Content Standard",
				"identifier": "f2a2d11c-6e2f-11e7-b4cd-c1116e0c93af",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItemTypes\/f2a2d11c-6e2f-11e7-b4cd-c1116e0c93af"
			},
			"conceptKeywords": ["numbers", "addition"],
			"educationLevel": ["PR"],
			"humanCodingScheme": "S.U.A.N",
			"fullStatement": "Students will understand how to add numbers.",
			"abbreviatedStatement": "Add Numbers",
			"notes": "Examples, research etc.",
			"language": "en",
			"statusStartDate": "2013-02-01"
		}],
		"CFAssociations": [{
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/a9e5f2d0-05e5-11e8-9df1-2104318b93a1",
			"identifier": "a9e5f2d0-05e5-11e8-9df1-2104318b93a1",
			"lastChangeDateTime": "2018-01-30T17:47:39+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "My _current_ children are in an alphabetical list: \r\na. Made",
				"identifier": "a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/a9d9d75c-05e5-11e8-9f53-bbf3ae69b922"
			},
			"associationType": "isChildOf",
			"destinationNodeURI": {
				"title": "S.U.A.N",
				"identifier": "987d0bd2-05e5-11e8-8801-5b23b21d3bc3",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/987d0bd2-05e5-11e8-8801-5b23b21d3bc3"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/b5a64d18-05e5-11e8-b572-c915fa3c41e4",
			"identifier": "b5a64d18-05e5-11e8-b572-c915fa3c41e4",
			"lastChangeDateTime": "2018-01-30T17:47:58+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "> My second child's name is Jocelyn.\r\n\r\n**Bold** \r\n*Italic*\r",
				"identifier": "b5a3a0ae-05e5-11e8-a812-537ba182d282",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/b5a3a0ae-05e5-11e8-a812-537ba182d282"
			},
			"associationType": "isChildOf",
			"destinationNodeURI": {
				"title": "S.U.A.N",
				"identifier": "987d0bd2-05e5-11e8-8801-5b23b21d3bc3",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/987d0bd2-05e5-11e8-8801-5b23b21d3bc3"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/7aeba2a2-1aaf-11e8-9a56-750acbdb39ec",
			"identifier": "7aeba2a2-1aaf-11e8-9a56-750acbdb39ec",
			"lastChangeDateTime": "2018-02-26T04:42:41+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "My _current_ children are in an alphabetical list: \r\na. Made",
				"identifier": "a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/a9d9d75c-05e5-11e8-9f53-bbf3ae69b922"
			},
			"associationType": "isRelatedTo",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "ecc6c4c1-6324-56e7-ae39-b3197b0dccb5",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/ecc6c4c1-6324-56e7-ae39-b3197b0dccb5"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/7f22efce-1aaf-11e8-a4af-910ccf537923",
			"identifier": "7f22efce-1aaf-11e8-a4af-910ccf537923",
			"lastChangeDateTime": "2018-02-26T04:42:48+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "My _current_ children are in an alphabetical list: \r\na. Made",
				"identifier": "a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/a9d9d75c-05e5-11e8-9f53-bbf3ae69b922"
			},
			"associationType": "exactMatchOf",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "cb02c151-5f97-5fb2-b68a-881442ac8cb9",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/cb02c151-5f97-5fb2-b68a-881442ac8cb9"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/82f4d428-1aaf-11e8-9cd5-ede6171cc67f",
			"identifier": "82f4d428-1aaf-11e8-9cd5-ede6171cc67f",
			"lastChangeDateTime": "2018-02-26T04:42:55+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "My _current_ children are in an alphabetical list: \r\na. Made",
				"identifier": "a9d9d75c-05e5-11e8-9f53-bbf3ae69b922",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/a9d9d75c-05e5-11e8-9f53-bbf3ae69b922"
			},
			"associationType": "replacedBy",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "b9d77f08-66f4-51d1-96d9-973a256165cc",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/b9d77f08-66f4-51d1-96d9-973a256165cc"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/8c0627ba-1aaf-11e8-a75d-915589ff379b",
			"identifier": "8c0627ba-1aaf-11e8-a75d-915589ff379b",
			"lastChangeDateTime": "2018-02-26T04:43:10+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "> My second child's name is Jocelyn.\r\n\r\n**Bold** \r\n*Italic*\r",
				"identifier": "b5a3a0ae-05e5-11e8-a812-537ba182d282",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/b5a3a0ae-05e5-11e8-a812-537ba182d282"
			},
			"associationType": "precedes",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "2b059ebc-b9fd-5149-b78f-ec2e5a10c4c5",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/2b059ebc-b9fd-5149-b78f-ec2e5a10c4c5"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/918ac5ba-1aaf-11e8-8987-f9eb79c3f6be",
			"identifier": "918ac5ba-1aaf-11e8-8987-f9eb79c3f6be",
			"lastChangeDateTime": "2018-02-26T04:43:19+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "> My second child's name is Jocelyn.\r\n\r\n**Bold** \r\n*Italic*\r",
				"identifier": "b5a3a0ae-05e5-11e8-a812-537ba182d282",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/b5a3a0ae-05e5-11e8-a812-537ba182d282"
			},
			"associationType": "hasSkillLevel",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "c8aaff00-1018-5c0a-9c23-ac900d6751fd",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/c8aaff00-1018-5c0a-9c23-ac900d6751fd"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/9621123c-1aaf-11e8-a947-e17b8d69465c",
			"identifier": "9621123c-1aaf-11e8-a947-e17b8d69465c",
			"lastChangeDateTime": "2018-02-26T04:43:27+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "> My second child's name is Jocelyn.\r\n\r\n**Bold** \r\n*Italic*\r",
				"identifier": "b5a3a0ae-05e5-11e8-a812-537ba182d282",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/b5a3a0ae-05e5-11e8-a812-537ba182d282"
			},
			"associationType": "isPeerOf",
			"destinationNodeURI": {
				"title": "Destination Node",
				"identifier": "7ac7b08d-7b81-5e25-843a-e5ec6789fc2d",
				"uri": "https:\/\/salt-demo.edplancms.com\/uri\/7ac7b08d-7b81-5e25-843a-e5ec6789fc2d"
			}
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/e4cebd4a-209e-11e8-99b0-d3a2a92a28b4",
			"identifier": "e4cebd4a-209e-11e8-99b0-d3a2a92a28b4",
			"lastChangeDateTime": "2018-03-05T17:59:15+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "H.A.Framework.A.B.1",
				"identifier": "e4c97cae-209e-11e8-b90c-b5e39335077d",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/e4c97cae-209e-11e8-b90c-b5e39335077d"
			},
			"associationType": "isChildOf",
			"destinationNodeURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"sequenceNumber": 2
		}, {
			"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFAssociations\/eae2913e-209e-11e8-bc0d-c15cf247eb4f",
			"identifier": "eae2913e-209e-11e8-bc0d-c15cf247eb4f",
			"lastChangeDateTime": "2018-03-05T17:59:15+00:00",
			"CFDocumentURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"originNodeURI": {
				"title": "S.U.A.N",
				"identifier": "987d0bd2-05e5-11e8-8801-5b23b21d3bc3",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItems\/987d0bd2-05e5-11e8-8801-5b23b21d3bc3"
			},
			"associationType": "isChildOf",
			"destinationNodeURI": {
				"title": "Demo Framework",
				"identifier": "72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc",
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFDocuments\/72d44e72-05e5-11e8-8dcd-6b6ccb2b01cc"
			},
			"sequenceNumber": 1
		}],
		"CFDefinitions": {
			"CFConcepts": [],
			"CFSubjects": [],
			"CFLicenses": [{
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFLicenses\/7eb5e85a-6fef-59f4-a5f2-6665ab9681db",
				"identifier": "7eb5e85a-6fef-59f4-a5f2-6665ab9681db",
				"lastChangeDateTime": "2018-02-05T19:35:18+00:00",
				"title": "Attribution 4.0 International",
				"description": "Creative Commons Attribution 4.0 International",
				"licenseText": "https:\/\/creativecommons.org\/licenses\/by\/4.0\/legalcode"
			}],
			"CFItemTypes": [{
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItemTypes\/f2a2d11c-6e2f-11e7-b4cd-c1116e0c93af",
				"identifier": "f2a2d11c-6e2f-11e7-b4cd-c1116e0c93af",
				"lastChangeDateTime": "2017-07-21T16:16:27+00:00",
				"title": "Content Standard",
				"typeCode": "Content Standard",
				"hierarchyCode": "1"
			}, {
				"uri": "http:\/\/frameworks-staging.act.org\/ims\/case\/v1p0\/CFItemTypes\/39ff729e-6b84-11e7-a04e-32dbd3c9a467",
				"identifier": "39ff729e-6b84-11e7-a04e-32dbd3c9a467",
				"lastChangeDateTime": "2017-07-18T06:42:11+00:00",
				"title": "Career Pathway",
				"typeCode": "Career Pathway",
				"hierarchyCode": "1"
			}],
			"CFAssociationGroupings": []
		}
	};

function getCFItemRelationship(identifier){
	
	var associations=[];
	for(var i=0;i<pdfData["CFAssociations"].length;i++){
		
		if(identifier==pdfData["CFAssociations"][i].originNodeURI.identifier){
			var associationObject={"origin":{},"relationhship":"","destination":{}};
			associationObject.origin=pdfData["CFAssociations"][i].originNodeURI;
			associationObject.relationhship=pdfData["CFAssociations"][i].associationType;
			associationObject.destination=pdfData["CFAssociations"][i].destinationNodeURI;
			
			associations.push(associationObject);
		}
	}
	return associations;
}
function downloadPdf(){
	var docDefinition={};
	
	if("creator" in pdfData["CFDocument"]){
		docDefinition.header={text:"Creator : " + pdfData["CFDocument"]["creator"],margin: [ 70, 10]};
	}
	if("licenseURI" in pdfData["CFDocument"] && "title" in pdfData["CFDocument"].licenseURI){
		docDefinition.footer={text:"License : "+pdfData["CFDocument"].licenseURI.title,margin: [ 70, 10,0,20]};
	}
	var content=[];
	
	if("title" in pdfData["CFDocument"]){
		content.push( { text:pdfData["CFDocument"].title,style:{ alignment: 'center'},margin:[0,70,0,0] , fontSize: 15 });	
	}
	if("publisher" in pdfData["CFDocument"]){
		content.push( { text:pdfData["CFDocument"].publisher ,style:{ alignment: 'center'},margin:[0,0] , fontSize: 10 });	
	}
	content.push( { text:"Created by CfDoc Organization, under a"+ pdfData["CFDocument"].licenseURI.title +" license" , fontSize: 12 , margin:[0,500,0,0] });
	content.push( { text:"Date : "+ pdfData["CFDocument"].statusStartDate  , fontSize: 12 });
	content.push( { text:"Draft : "+"Draft field is not present in case file right now"  ,pageBreak: 'after', fontSize: 12 });
	
	//for cfitems
	content.push( { text:"Framework Elements" , style:{ alignment: 'center'},margin:[0,30,0,0] , fontSize: 15  });
	
	for(var i=0;i<pdfData.CFItems.length;i++){
		content.push( { text:"",margin:[0,20,0,0] });
		
		if("humanCodingScheme" in pdfData.CFItems[i]){
			
			content.push( { text:"Human Coding Scheme : "+  pdfData.CFItems[i].humanCodingScheme,margin:[0,10,0,0] ,style:{ bold: true}, fontSize: 11 });
		}
		
		if("abbreviatedStatement" in pdfData.CFItems[i]){
			content.push( { text:"Abbreviated Statement : "+ pdfData.CFItems[i].abbreviatedStatement  , fontSize: 11 ,margin:[0,10,0,0]});
		}
		
		
		if("fullStatement" in pdfData.CFItems[i]){
			content.push( { text:"Full Statement : "+ pdfData.CFItems[i].fullStatement  , fontSize: 11 ,margin:[0,10,0,0]});	
		}
		
		if("CFItemType" in pdfData.CFItems[i]){
			content.push( { text:"Item Type :  "+pdfData.CFItems[i].CFItemType  , fontSize: 11 ,margin:[0,10,0,0]});
		}
		
		if("notes" in pdfData.CFItems[i]){
			content.push( { text:"Notes : "+pdfData.CFItems[i].notes  , fontSize: 11 ,margin:[0,10,0,0]});
		}
		if("conceptKeywords" in pdfData.CFItems[i]){
			content.push( { text:"Concept Keywords : " + pdfData.CFItems[i].conceptKeywords.toString()  , fontSize: 11 ,margin:[0,10,0,0]});
		}
		var relationshipData=getCFItemRelationship(pdfData.CFItems[i].identifier);
		
		content.push( { text:"Relationships with Other Frameworks", style:{ alignment: 'center'}, fontSize: 12 ,margin:[0,20,0,20]});
		
		//create association table
		var body=[];
		var tableData=[];
		//table headers
		body.push([{text: 'Framework', bold: true},{text: 'Relationship', bold: true} ,{text: 'Other Statement', bold: true} ]);
		
		for(var j=0;j<relationshipData.length;j++){
			tableData=[];
			tableData.push({text: relationshipData[j].origin.title, style:{fontSize:11}},{ text: relationshipData[j].relationhship, style:{fontSize:11}},{ text: relationshipData[j].destination.title, style:{fontSize:11}})
			body.push(tableData);
			
		}
		
		
		 var table= {
		        headerRows: 1,
		        widths: [ '*', '*', '*' ],
		        body: body
		       
		      }
		
		 content.push({table:table})
		if(i<pdfData.CFItems.length-1){
			content.push( {text:"",pageBreak: 'after'});
		}
		
		
	}
	
	


	
	
	docDefinition.content= content;
	
	
	
//	var docDefinition = {
//			  content: [
//			    {
//			      table: {
//			        // headers are automatically repeated if the table spans over multiple pages
//			        // you can declare how many rows should be treated as headers
//			        headerRows: 1,
//			        widths: [ 'auto', 'auto', 'auto' ],
//
//			        body: [
//			          [ 'First', 'Second', 'Third' ],
//			          [ { text: 'Bold value', bold: true }, 'Val 2', 'Val 3' ]
//			        ]
//			      }
//			    }
//			  ]
//			};
	
pdfMake.createPdf(docDefinition).open();
	//pdfMake.createPdf(docDefinition).download('optionalName.pdf');
}
